package com.zybooks.weighttracker;

public class UserLogin {

    private String mUsername;
    private String mPassword;
    private String mRole;

    public UserLogin() {}

    public UserLogin(String username, String password, String role) {
        mUsername = username;
        mPassword = password;
        mRole = role;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public String getRole() {
        return mRole;
    }

    public void setRole(String role) {
        mRole = role;
    }

}
