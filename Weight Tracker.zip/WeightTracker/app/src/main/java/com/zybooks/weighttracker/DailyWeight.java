package com.zybooks.weighttracker;

public class DailyWeight {

    private long mId;
    private String mDate;
    private Short mDailyWeight;
    private String mUsername;

    public DailyWeight() {}

    public DailyWeight(String date, short weight, String username) {

        mDate = date;
        mDailyWeight = weight;
        mUsername = username;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getDate() {
        return mDate;
    }

    public void setDailyWeight(Short weight) {
        mDailyWeight = weight;
    }

    public Short getDailyWeight() {
        return mDailyWeight;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }

}
