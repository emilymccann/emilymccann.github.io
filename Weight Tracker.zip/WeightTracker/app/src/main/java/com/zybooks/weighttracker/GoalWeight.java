package com.zybooks.weighttracker;

public class GoalWeight {

    //private long mId;
    private Short mGoalWeight;
    private String mUsername;
    private String mGoal;
    private String mReceiveCongrats;

    public GoalWeight() {}

    public GoalWeight(Short weight, String username, String goal, String receiveCongrats) {
        mGoalWeight = weight;
        mUsername = username;
        mGoal = goal;
        mReceiveCongrats = receiveCongrats;
    }

    public void setGoalWeight(Short weight) {
        mGoalWeight = weight;
    }

    public Short getGoalWeight() {
        return mGoalWeight;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setGoal(String goal) {
        mGoal = goal;
    }

    public String getGoal() {
        return mGoal;
    }

    public void setCongrats(String receiveCongrats) {
        mReceiveCongrats = receiveCongrats;
    }

    public String getCongrats() {
        return mReceiveCongrats;
    }
}
