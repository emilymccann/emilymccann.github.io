package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import java.util.Calendar;

public class EditDailyWeightActivity extends AppCompatActivity {

    // Widgets
    private EditText mDateInput;
    private EditText mWeightInput;
    private Button mSaveButton;
    private DatePickerDialog datePickerDialog;

    // Vars and objects
    public static final String EXTRA_DAILY_WT_ID = "com.zybooks.weighttracker.dailyWtId";
    private WeightTrackerDatabase mWeightTrackerDB;
    private DailyWeight mDailyWeight;

    // TextWatcher for dynamically enabling/disabling the add button
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged (CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //enable button when user enters text
            if (s.length() > 0) {
                mSaveButton.setEnabled(true);
            }
            // when there is no text, disable button
            else {
                mSaveButton.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_daily_weight);

        long id;

        mDateInput = findViewById(R.id.dateEditText);
        mWeightInput = findViewById(R.id.weightEditText);
        mSaveButton = findViewById(R.id.saveButton);

        mWeightTrackerDB = WeightTrackerDatabase.getInstance(getApplicationContext());

        // Get id from the recycler view adapter
        Intent intent = getIntent();
        id = intent.getLongExtra(EXTRA_DAILY_WT_ID, -1);

        // Get the existing daily weight entry
        mDailyWeight = mWeightTrackerDB.getDailyWeight(id);

        String oldDate = mDailyWeight.getDate();
        Short oldWeightShort = mDailyWeight.getDailyWeight();
        String oldWeightString = oldWeightShort.toString();

        //set text inputs to show old values
        mDateInput.setText(oldDate);
        mWeightInput.setText(oldWeightString);

        // Set text changed listener for the EditText
        mWeightInput.addTextChangedListener(textWatcher);

        //button enabled upon activity launch since fields will contain previous data
        mSaveButton.setEnabled(true);

        //make mDateInput not typable but clickable
        mDateInput.setFocusable(false);
        mDateInput.setClickable(true);

        //set on click listener for mDateInput to open date picker dialog
        mDateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); //current year
                int mMonth = c.get(Calendar.MONTH); //current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); //current date

                datePickerDialog = new DatePickerDialog(EditDailyWeightActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            //chosen date will appear in mDateInput
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                mDateInput.setText((monthOfYear + 1) + "/" + dayOfMonth + "/" + year);
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    // saves the daily weight
    public void onSaveClick(View view) {
        String newDate = mDateInput.getText().toString();
        String newWeightString = mWeightInput.getText().toString();
        Short newWeightShort = Short.parseShort(newWeightString);

        //update daily weight entry with new values
        mDailyWeight.setDate(newDate);
        mDailyWeight.setDailyWeight(newWeightShort);

        //update in db
        mWeightTrackerDB.updateDailyWeight(mDailyWeight);

        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

}